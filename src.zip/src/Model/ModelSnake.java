package Model;

import java.util.ArrayList;

import java.util.Random;

import static java.lang.Math.random;

public class ModelSnake {
    public ArrayList<Integer> x = new ArrayList<Integer>(), y = new ArrayList<Integer>();


    int w = 30;
    int h = 30;
    int blocks = 20;
    public int move = 2;

    int foodX = 15;
    int foodY = 15;
    int food2X = 15;
    int food2Y = 15;
    int speed = 8;
    public int score = 0;
    boolean gameOver = false;
    int[] x_move = {0, 0, 1, -1}, y_move = {1, -1, 0, 0};
    Random random = new Random();
    int a = random.nextInt(w);
    int b = random.nextInt(h);


    public ArrayList<Integer> getX() {
        return x;
    }

    public ArrayList<Integer> getY() {
        return y;
    }
    public int getFood2X() {
        return food2X;
    }

    public void setMove(int move) {
        this.move = move;
    }
    public void setFoodX(int foodX){

    }
    public int getFood2Y() {
        return food2Y;
    }

    public ModelSnake() {
        x.add(0);
        y.add(15);
        foodX = (int) random()* w; // muss angepasst werden.
        foodY = (int) (random() * h);
        food2X = (int) (random() * 30); // muss angepasst werden.
        food2Y = (int) (random() * 30);
    }

    public int getFoodX() {
        return foodX;
    }

    public int getFoodY() {
        return foodY;
    }


    public void game() {

        if (!gameOver) {
            int frameCount = 0;
            if (frameCount % speed == 0) {
                /* make my snake longer*/
                x.add(0, x.get(0) + x_move[move]);
                y.add(0, y.get(0) + y_move[move]);


                if ((x.get(0) == foodX && y.get(0) == foodY)) {
                    if (x.size() % 5 == 0 && speed >= 2) {
                        speed -= 1;
                    }
                    foodX = (int) (random() * 30); // muss angepasst werden.
                    foodY = (int) (random() * 30); // muss angepasst werden.
                } else if ((x.get(0) == food2X && y.get(0) == food2Y)) {
                    if (x.size() % 5 == 0 && speed >= 2) {
                        speed -= 1;
                    }
                    food2X = (int) (random()* w) ; // muss angepasst werden.
                    food2Y = (int) (random() * h) ; // muss angepasst werden.
                } else {
                    /* remove last blocks from arraylist*/
                    x.remove(x.size() - 1);
                    y.remove(y.size() - 1);
                }

            }
            bounding2();
            bounding1();
           /* badFood();*/
        }
    }



    public void badFood() {
        if ((x.get(0) == food2X && y.get(0) == food2Y)){
           gameOver = true;

        }
    }
    public void bounding1(){
        if(y.get(0) < 0 || y.get(0) >=h){
            gameOver = true;
        }
    }
    public void bounding2(){
        if (x.get(0) < 0){
            x.set(0,w-1);
        }
        if (x.get(0) > w){
            x.set(0,0);
        }
       /* if(y.get(0) < 0){
            x.add(0,h-1);
            //x.set(0,h-1);
        }
        if(y.get(0) > h){
            x.add(0,0);
        }*/
    }
    public int getMove() {
        return this.move;
    }

    public boolean is_game_over() {
        for (int i = 1; i < x.size(); i++) {
            if (x.get(0) == x.get(i) && y.get(0) == y.get(i)) {
                x.clear();
                y.clear();
                reset();
                return true;
            }
        }
        return false;


    }
    public void reset(){
        x.add(0);
        y.add(15);
        move = 2;
        speed = 8;
        gameOver = false;
    }

}
