package View;

import Controller.ControlSnake;
import Controller.Direction;
import Controller.IController;
import Controller.IView;
import processing.core.PApplet;

import java.util.ArrayList;
import java.util.List;

public class ViewSnake extends PApplet implements IView{
    public static void main(String[] args) {
        PApplet.main(ViewSnake.class);
    }

    private int  blocks = 20, move = 2, direction = 0, speed = 7;
    private ControlSnake controller;

    public boolean gamestarted;

    public void settings() {
        size(600, 600);
    }

    public void setup() {
        frameRate(6);
        controller = new ControlSnake((ViewSnake) this);
    }

    public void draw() {
        controller.nextFrame();
    }

    public void drawTitleScreen() {
        super.background(color(56, 168, 50));
        super.textAlign(CENTER, CENTER);
        super.noStroke();
        super.textSize(30);
        super.text("Welcom to Snake game ", width / 4, height / 4);
        super.textSize(64);
        super.text("Game Start", width / 3, height / 3);
        super.textSize(16);
        super.text("Press any key to start", width / 2, height / 2);
        super.fill(255);
    }

    public void setupGame() {
        super.textAlign(CENTER);
        super.textSize(27);
        super.noStroke();
        super.background(color(0, 0, 0));
        super.colorMode(HSB, 360, 100, 100);

        controller.setupGrid();
    }


    @Override
    public void drawGame(List<Integer> x, List<Integer> y, int foodX, int foodY, int food2X, int food2Y) {
        super.background(0);
        super.fill(56, 168, 50);
        for (int i = 0; i < x.size(); i++) {
            super.rect(x.get(i) * blocks, y.get(i) * blocks, blocks, blocks);
        }
        super.fill(255,0,255);
        super.ellipse(foodX * blocks, foodY * blocks, blocks, blocks);
        super.fill(255,255,255);
        super.ellipse(food2X * blocks, food2Y * blocks, blocks, blocks);

            textAlign(RIGHT);
            textSize(30);
            fill(255);
            text("Score: " + x.size(),10,10, width-20,50);


    }

    /*public void keyPressed() {
        controller.userInput();
    }*/
    public void keyPressed() {
        if (!gamestarted) {
            controller.startgame();
            gamestarted = true;
        }
        if (key == CODED) {
            switch (keyCode) {
                case LEFT:
                    controller.userInput(Direction.LEFT);
                    break;
                case RIGHT:
                    controller.userInput(Direction.RIGHT);
                    break;
                case UP:
                    controller.userInput(Direction.UP);
                    break;
                case DOWN:
                    controller.userInput(Direction.DOWN);
            }
        }
    }




    @Override
    public void drawGameOver() {
        super.colorMode(RGB, 255, 255, 255);
        super.background(color(0, 0, 0));
        super.textAlign(CENTER, CENTER);
        super.noStroke();
        super.textSize(64);
        super.text("Gameover", width / 2, height / 2);
        super.textSize(16);
        super.fill(255);
    }



}
