

import processing.core.PApplet;

import java.util.ArrayList;

public class gameLogin extends  PApplet {
    public static void main(String[] args) {
        PApplet.main(gameLogin.class);
    }

    ArrayList<Integer> x = new ArrayList<Integer>(), y = new ArrayList<Integer>();
    int w =30, h =30, blocks = 20, move =2;
    int direction = 0;
    int foodX =15, foodY=15, speed=7;
    boolean gameOver = false;
    int[] x_move = {0,0,1,-1}, y_move = {1,-1,0,0};

    public void settings() {
        size(600, 600);
    }

    public void setup(){
        x.add(0);
        y.add(0);
    }
    public void draw() {
            background(0);
            fill(56, 168, 50);
            for (int i = 0; i < x.size(); i++) rect(x.get(i) * blocks, y.get(i) * blocks, blocks, blocks);
            eat();
            food();
            score();
            bouding();



    }
    public void keyPressed(){
        direction = keyCode == DOWN ?0:(keyCode== UP?1:(keyCode== LEFT?3:(keyCode== RIGHT?2:-1)));
        if (direction != -1) move =direction;

    }
    public void food() {
        if (!gameOver) {
            fill(255);
            ellipse(foodX * blocks, foodY * blocks, blocks, blocks);
        }
    }
    public void eat() {
        if(!gameOver){
            if (frameCount % speed == 0) {
                x.add(0, x.get(0) + x_move[move]);
                y.add(0, y.get(0) + y_move[move]);


                if (x.get(0) == foodX && y.get(0) == foodY) {
                    if (x.size() % 5 == 0 && speed >= 2) {
                        speed -= 1;
                    }
                    foodX = (int) random(0, w);
                    foodY = (int) random(0, h);
                } else {
                    x.remove(x.size() - 1);
                    y.remove(y.size() - 1);
                }
            }
        }

    }
    public void score(){
        textAlign(RIGHT);
        textSize(30);
        fill(255);
        text("Score: " + x.size(),10,10, width-20,50);
    }
    public void bouding(){
        if(x.get(0)< 0 || y.get(0) < 0 || x.get(0)>= w || y.get(0) >= h){
            x.clear();
            y.clear();
        }
        textAlign(CENTER);
        textSize(30);
        fill(219,186,18);
        /*text("Game Over \n your score is  " + x.size() + "\n Press ENTER If you want to play again" ,width-20,50);
        if (keyCode == ENTER){
            x.add(0);
            y.add(16);
            move = 2;
            speed = 7;
        }*/
    }
    public void die(){
        for(int i =1 ; i< x.size(); i++){
            if (x.get(0) == x.get(i) && y.get(0) == y.get(i)){
                x.clear();
                y.clear();
            }
        }
    }

}
