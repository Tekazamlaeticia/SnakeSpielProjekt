package Controller;

import java.util.List;

public interface IView {
    public void drawTitleScreen();
    public void setupGame();
    public void drawGame(List<Integer> x, List<Integer> y, int foodX, int foodY, int food2X, int food2Y);
    public void drawGameOver();


}
