package Controller;

public enum Direction {
    LEFT, RIGHT, UP, DOWN
}
