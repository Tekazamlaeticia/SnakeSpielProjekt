package Controller;

public enum GameState {
    TITLE_SCREEN,
    GAME,
    GAME_OVER

}
