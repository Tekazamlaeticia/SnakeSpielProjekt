package Controller;

import Model.ModelSnake;
import View.ViewSnake;

public class ControlSnake implements IController {
    private ViewSnake view;
    private GameState state;
    private ModelSnake model;
    int xChange;

    int score = 0;
    Direction direction;

    public ControlSnake(ViewSnake view) {
        direction = Direction.RIGHT;
        this.view = view;
        this.state = GameState.TITLE_SCREEN;
        this.model = new ModelSnake();

    }

    private void setSnakeDirection() {
        switch (this.direction) {
            case LEFT -> model.setMove (3);
            case RIGHT -> model.setMove(2);
            case UP -> model.setMove(1);
            case DOWN -> model.setMove(0);
        }
    }

    @Override
    public void nextFrame() {
        switch (state) {
            case TITLE_SCREEN -> {
                view.drawTitleScreen();
            }
            case GAME -> {
                this.setSnakeDirection();
                model.game();
                view.drawGame(model.getX(), model.getY(), model.getFoodX(), model.getFoodY(), model.getFood2X(), model.getFood2Y());
                if (model.is_game_over()) {
                    state = GameState.GAME_OVER;
                    System.out.println("your score ist:" +model.x.size());
                }
            }

            case GAME_OVER -> {

                view.drawGameOver();
            }

        }

    }

    @Override
    public void userInput(Direction direction) {
        switch (state) {
            case TITLE_SCREEN -> {
                view.setupGame();
                state = GameState.GAME;
                return; //userInput bricht ab und es wird noch keine neue Tile erzeugt
            }
            case GAME -> {
                this.direction = direction;

            }
        }
    }


    @Override
    public void setupGrid() {

    }

    public void startgame() {
        this.state = GameState.GAME;
    }
}
