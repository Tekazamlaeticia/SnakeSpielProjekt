package Controller;

public interface IController {
    public void nextFrame();
    public void userInput(Direction direction);
    public  void startgame();
    public void setupGrid();
}



